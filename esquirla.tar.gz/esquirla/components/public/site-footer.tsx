import Link from 'next/link';
import { NAV_LINKS } from '@/lib/constants';

export function SiteFooter({
  magazineName,
  tagline,
  contactEmail,
  instagram,
}: {
  magazineName: string;
  tagline: string | null;
  contactEmail: string | null;
  instagram: string | null;
}) {
  return (
    <footer className="mt-24 border-t-2 border-carbon bg-carbon text-paper">
      <div className="mx-auto grid max-w-6xl gap-10 px-5 py-14 sm:grid-cols-2">
        <div>
          <p className="wordmark text-5xl sm:text-6xl">{magazineName}</p>
          {tagline ? <p className="mt-4 max-w-xs text-paper/70">{tagline}</p> : null}
        </div>

        <div className="flex flex-col gap-8 sm:items-end">
          <nav aria-label="Pie de página">
            <ul className="flex flex-wrap gap-x-5 gap-y-2 sm:justify-end">
              {NAV_LINKS.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="font-mono text-[0.72rem] uppercase tracking-[0.16em] text-paper/70 hover:text-rojo"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div className="space-y-1 font-mono text-[0.72rem] uppercase tracking-[0.14em] text-paper/60 sm:text-right">
            {contactEmail ? (
              <p>
                <a href={`mailto:${contactEmail}`} className="hover:text-rojo">
                  {contactEmail}
                </a>
              </p>
            ) : null}
            {instagram ? <p>{instagram}</p> : null}
            <p>{new Date().getFullYear()}</p>
          </div>
        </div>
      </div>

      <div className="cinta h-2" aria-hidden="true" />
    </footer>
  );
}
